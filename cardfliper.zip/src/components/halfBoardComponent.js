import React, {useContext} from "react";
import CardComponent from "./cardComponent/cardComponent";
import Context from "../context";


const HalfBoard = (props) => {
    const playBoard = {
        display: "flex",
        flexWrap: "wrap"
    }
        return (
            <div style={playBoard}>
                {props.stateArray.map((card,index) => {
                    return <CardComponent key={card.id} cardIndex={index} card={card}
                                          stateArray={props.stateArray} setStateArray={props.setStateArray}
                                          firstCard={props.firstCard} setFirstCard={props.setFirstCard}
                                          secondCard={props.secondCard} setSecondCard={props.setSecondCard}
                    />
                })}
            </div>
    )

}
export default HalfBoard