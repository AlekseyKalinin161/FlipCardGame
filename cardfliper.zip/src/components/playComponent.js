import React, {useContext, useState} from "react";
import {Link} from "react-router-dom";
import HalfBoard from "./halfBoardComponent";
import Context from "../context";
import HomeComponent from "./homeComponent";



const PlayComponent = (props) => {

    const [firstCard, setFirstCard] = useState('')
    const [secondCard, setSecondCard] = useState('')
    const playBoard = {
        display: "flex",
        flexWrap: "wrap",
        border: "2px solid red",
        width: "100%",
        height: "100%",
        margin: "0"
    }
    const ButtonPanel = () => {
        return (
            <div>
                <Link to="/play">
                    <button onClick={<PlayComponent/>}>Новая игра</button>
                </Link>
                <Link to="/">
                    <button>Назад</button>
                </Link>
            </div>
        )
    }

    function comparisonId (idCards, setIdCards){

    }

    // function comparisonId (card,setStateCard){
    //     let id = card.id
    //     idArray.push(id)
    //
    //     if (idArray.length === 2){
    //         if(idArray[0] === idArray[1]){
    //             const targetCard = props.arrayCard.find((card) => card.id === id);
    //             targetCard.state = 'front';
    //             setStateCard('front')
    //
    //         }
    //         idArray = [] ;
    //
    //     }
    // }
    return (
        <div>
            <div style={playBoard}>
                <HalfBoard
                    stateArray={props.stateArray} setStateArray={props.setStateArray} idArray={props.idArray}
                    firstCard={firstCard} setFirstCard={setFirstCard} secondCard={secondCard} setSecondCard={setSecondCard}
                />
                {/*<HalfBoard*/}
                {/*    stateArray={props.stateArray} setStateArray={props.setStateArray}*/}
                {/*/>*/}
            </div>
            <ButtonPanel/>
        </div>
    )
}
export default PlayComponent