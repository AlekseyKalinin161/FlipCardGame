import React from "react";
import "./cardComponent.css"

let idArray = [];

const CardComponent = (props) => {


    function flipper(card, i) {
        const targetCard = props.stateArray.find((card) => props.stateArray.indexOf(card) === i);
        targetCard.state = "back";
        props.setStateArray([...props.stateArray]);
        idArray.push(card.id)
        if (idArray.length === 2) {
            if (idArray[0] === idArray[1]) {
                console.log('=');
                targetCard.disabled = true;
                props.setStateArray([...props.stateArray]);
            }
            idArray = [];
            targetCard.state = "front";
            props.setStateArray([...props.stateArray]);

        }
        console.log(idArray)
    }

    return (
        <button className="scene scene--card" disabled={props.card.disabled}
                onClick={() => flipper(props.card, props.cardIndex)}>
            <div className={`card ${props.card.state === "back" ? "is-flipped" : ""}`}>
                <div className="card__face card__face--front">front</div>
                <div className="card__face card__face--back">{props.card.id}</div>
            </div>
        </button>
    )
}
export default CardComponent