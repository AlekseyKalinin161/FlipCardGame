import './App.css';
import HomeComponent from "./components/homeComponent";
import Context from "./context";
import {useState} from "react";

function App() {
    const arrayCard = [
        {
            id: 1,
            disabled: false,
            state:"front",
            cardFront: "",
            cardBack: ""
        },
        {
            id: 2,
            disabled: false,
            state:"front",
            cardFront: "",
            cardBack: ""
        },
        {
            id: 3,
            disabled: false,
            state:"front",
            cardFront: "",
            cardBack: ""
        },
        {
            id: 4,
            disabled: false,
            state:"front",
            cardFront: "",
            cardBack: ""
        },
        {
            id: 1,
            disabled: false,
            state:"front",
            cardFront: "",
            cardBack: ""
        },
        {
            id: 2,
            disabled: false,
            state:"front",
            cardFront: "",
            cardBack: ""
        },
        {
            id: 3,
            disabled: false,
            state:"front",
            cardFront: "",
            cardBack: ""
        },
        {
            id: 4,
            disabled: false,
            state:"front",
            cardFront: "",
            cardBack: ""
        }
    ]
    let idArray = [];
    const [stateArray, setStateArray] = useState(arrayCard)
    return (
    <div className="App">
        <Context.Provider value={{}}>
        <HomeComponent
            stateArray={stateArray} setStateArray={setStateArray} idArray={idArray}
        />
        </Context.Provider>
    </div>
  );

}

export default App;
